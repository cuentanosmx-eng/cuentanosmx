<?php
/**
 * Cuentanos MX - Child Theme Functions
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

define('CNMX_VERSION', '2.0.1');
define('CNMX_PATH', get_stylesheet_directory());
define('CNMX_URL', get_stylesheet_directory_uri());

/**
 * Enqueue parent and custom styles
 */
function Cuentanos_enqueue_styles() {
    // Parent theme CSS - use version from style.css
    $parent_version = wp_get_theme('astra')->get('Version');
    wp_enqueue_style(
        'astra-theme',
        get_template_directory_uri() . '/style.css',
        [],
        $parent_version
    );
    
    // Custom CSS - Airbnb Style
    wp_enqueue_style(
        'cnmx-main',
        CNMX_URL . '/assets/css/main.css',
        ['astra-theme'],
        CNMX_VERSION
    );
    
    // Animations CSS
    wp_enqueue_style(
        'cnmx-animations',
        CNMX_URL . '/assets/css/animations.css',
        ['cnmx-main'],
        CNMX_VERSION
    );
    
    // Google Fonts - Inter
    wp_enqueue_style(
        'cnmx-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
        [],
        CNMX_VERSION
    );
}
add_action('wp_enqueue_scripts', 'Cuentanos_enqueue_styles', 20);

/**
 * Enqueue JavaScript
 */
function Cuentanos_enqueue_scripts() {
    // Leaflet Map JS
    wp_enqueue_script(
        'leaflet-js',
        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
        [],
        '1.9.4',
        true
    );
    
    // Main App JS
    wp_enqueue_script(
        'cnmx-app',
        CNMX_URL . '/assets/js/app.js',
        ['jquery'],
        CNMX_VERSION,
        true
    );
    
    // Localize data
    wp_localize_script('cnmx-app', 'cnmxData', [
        'apiUrl' => rest_url('cnmx/v1'),
        'nonce' => wp_create_nonce('wp_rest'),
        'userId' => get_current_user_id(),
        'isLoggedIn' => is_user_logged_in(),
        'homeUrl' => home_url(),
        'strings' => [
            'loading' => 'Cargando...',
            'error' => 'Algo salio mal',
            'saved' => 'Guardado en favoritos',
            'removed' => 'Eliminado de favoritos',
            'open' => 'Abierto',
            'closed' => 'Cerrado',
        ]
    ]);
}
add_action('wp_enqueue_scripts', 'Cuentanos_enqueue_scripts', 20);

/**
 * Setup theme
 */
function Cuentanos_setup() {
    // Theme supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'gallery', 'caption']);
    
    // Image sizes
    add_image_size('cnmx-card', 400, 300, true);
    add_image_size('cnmx-thumbnail', 150, 150, true);
    add_image_size('cnmx-gallery', 800, 600, true);
    
    // Hide admin bar for non-admins
    add_filter('show_admin_bar', '__return_false');
}
add_action('after_setup_theme', 'Cuentanos_setup');

/**
 * Create required pages on theme activation
 */
function Cuentanos_create_pages() {
    $pages = [
        'directorio' => ['title' => 'Directorio', 'content' => ''],
        'registro' => ['title' => 'Registro', 'content' => ''],
        'mi-cuenta' => ['title' => 'Mi Cuenta', 'content' => ''],
        'perfil' => ['title' => 'Mi Perfil', 'content' => ''],
        'registrar-negocio' => ['title' => 'Registrar Negocio', 'content' => ''],
    ];
    
    foreach ($pages as $slug => $page) {
        $existing = get_page_by_path($slug);
        if (!$existing) {
            wp_insert_post([
                'post_title' => $page['title'],
                'post_name' => $slug,
                'post_content' => $page['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
            ]);
        }
    }
}
add_action('after_switch_theme', 'Cuentanos_create_pages');
