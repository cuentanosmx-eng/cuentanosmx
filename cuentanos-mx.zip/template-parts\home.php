<?php
/**
 * Home Page Template - Airbnb Style
 */

get_template_part('template-parts/header');

// Demo data for businesses
$negocios_data = [
    [
        'title' => 'La Casa de los Tacos',
        'category' => 'Restaurantes',
        'rating' => 4.8,
        'reviews' => 156,
        'location' => 'Centro Histórico',
        'imagen' => 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&h=400&fit=crop',
        'slug' => 'la-casa-de-los-tacos'
    ],
    [
        'title' => 'Café del Mar',
        'category' => 'Cafeterías',
        'rating' => 4.6,
        'reviews' => 89,
        'location' => 'Zona Romántica',
        'imagen' => 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=600&h=400&fit=crop',
        'slug' => 'cafe-del-mar'
    ],
    [
        'title' => 'Hotel Boutique La Paz',
        'category' => 'Hoteles',
        'rating' => 4.9,
        'reviews' => 234,
        'location' => 'Playa Principal',
        'imagen' => 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop',
        'slug' => 'hotel-boutique-la-paz'
    ],
    [
        'title' => 'Boutique Moda Latina',
        'category' => 'Tiendas de ropa',
        'rating' => 4.5,
        'reviews' => 67,
        'location' => 'Centro Comercial',
        'imagen' => 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop',
        'slug' => 'boutique-moda-latina'
    ],
    [
        'title' => 'Spa Relax & Wellness',
        'category' => 'Spa / Masajes',
        'rating' => 4.7,
        'reviews' => 112,
        'location' => 'Zona Hotelera',
        'imagen' => 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&h=400&fit=crop',
        'slug' => 'spa-relax-wellness'
    ],
    [
        'title' => 'Bar El Dorado',
        'category' => 'Bares',
        'rating' => 4.4,
        'reviews' => 78,
        'location' => 'Barrio nightlife',
        'imagen' => 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&h=400&fit=crop',
        'slug' => 'bar-el-dorado'
    ],
    [
        'title' => 'Gimnasio PowerFit',
        'category' => 'Gimnasios',
        'rating' => 4.3,
        'reviews' => 145,
        'location' => 'Av. Principal',
        'imagen' => 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=400&fit=crop',
        'slug' => 'gimnasio-powerfit'
    ],
    [
        'title' => 'Pastelería Dulces Sueños',
        'category' => 'Postres',
        'rating' => 4.9,
        'reviews' => 203,
        'location' => 'Colonia Centro',
        'imagen' => 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?w=600&h=400&fit=crop',
        'slug' => 'pasteleria-dulces-suenos'
    ],
];

// Categories with icons
$cat_icons = [
    'restaurantes' => '🍽️',
    'cafeterías' => '☕',
    'hoteles' => '🏨',
    'bares' => '🍺',
    'tiendas' => '🛍️',
    'spa' => '💆',
    'gimnasios' => '💪',
    'postres' => '🍰',
];

$categories = [
    ['name' => 'Restaurantes', 'slug' => 'restaurantes'],
    ['name' => 'Cafeterías', 'slug' => 'cafeterias'],
    ['name' => 'Hoteles', 'slug' => 'hoteles'],
    ['name' => 'Bares', 'slug' => 'bares'],
    ['name' => 'Tiendas', 'slug' => 'tiendas'],
    ['name' => 'Spa', 'slug' => 'spa'],
    ['name' => 'Gimnasios', 'slug' => 'gimnasios'],
    ['name' => 'Postres', 'slug' => 'postres'],
];
?>

<main>
    <!-- HERO SECTION -->
    <section class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Descubre los mejores lugares cerca de ti</h1>
            <p class="hero-subtitle">Negocios locales recomendados por la comunidad</p>
            
            <!-- SEARCH BOX -->
            <div class="search-box">
                <form class="search-form" action="<?php echo home_url('/directorio'); ?>" method="GET">
                    <div class="search-field">
                        <label>¿Qué buscas?</label>
                        <input type="text" name="q" placeholder="Restaurantes, cafés, hoteles...">
                    </div>
                    <div class="search-field">
                        <label>Categoría</label>
                        <select name="categoria">
                            <option value="">Todas las categorías</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo esc_attr($cat['slug']); ?>"><?php echo esc_html($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="search-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Buscar
                    </button>
                </form>
            </div>
            
            <!-- QUICK CATEGORIES -->
            <div class="quick-cats">
                <?php foreach ($categories as $cat): 
                    $icono = isset($cat_icons[$cat['slug']]) ? $cat_icons[$cat['slug']] : '📍';
                ?>
                    <a href="<?php echo home_url('/directorio?categoria=' . $cat['slug']); ?>" class="quick-cat">
                        <span class="quick-cat-icon"><?php echo $icono; ?></span>
                        <span><?php echo esc_html($cat['name']); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- MEGAFONOS BANNER -->
    <?php if (!is_user_logged_in()): ?>
    <section class="megafonos-banner">
        <div class="container">
            <div class="megafonos-banner-inner">
                <span class="megafonos-banner-icon">🎤</span>
                <div class="megafonos-banner-text">
                    <h3>¡Únete a Cuentanos.mx!</h3>
                    <p>Gana Megáfonos con cada reseña y favorito. Cánjealos por recompensas exclusivas.</p>
                </div>
                <a href="<?php echo home_url('/registro'); ?>" class="btn btn-white btn-lg">Regístrate gratis</a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- FEATURED BUSINESSES -->
    <section class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Negocios Destacados</h2>
                <a href="<?php echo home_url('/directorio'); ?>" class="section-link">Ver todos →</a>
            </div>
            
            <div class="businesses-grid">
                <?php foreach ($negocios_data as $biz): ?>
                    <a href="<?php echo home_url('/negocio/' . $biz['slug']); ?>" class="business-card">
                        <div class="business-card-img">
                            <img src="<?php echo esc_url($biz['imagen']); ?>" alt="<?php echo esc_attr($biz['title']); ?>">
                            <button class="business-card-fav" onclick="event.preventDefault(); this.classList.toggle('active');">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                                </svg>
                            </button>
                        </div>
                        <div class="business-card-content">
                            <span class="business-card-cat"><?php echo esc_html($biz['category']); ?></span>
                            <h3 class="business-card-title"><?php echo esc_html($biz['title']); ?></h3>
                            <div class="business-card-rating">
                                <span class="business-card-stars">
                                    <?php for ($i = 0; $i < 5; $i++): ?>
                                        <span class="<?php echo $i < floor($biz['rating']) ? '' : 'empty'; ?>">★</span>
                                    <?php endfor; ?>
                                </span>
                                <span class="business-card-rating-num"><?php echo number_format($biz['rating'], 1); ?></span>
                                <span class="business-card-reviews">(<?php echo $biz['reviews']; ?>)</span>
                            </div>
                            <div class="business-card-location">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                                    <circle cx="12" cy="10" r="3"/>
                                </svg>
                                <span><?php echo esc_html($biz['location']); ?></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA SECTION -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>¿Tienes un negocio?</h2>
                <p>Llega a miles de clientes locales y muestra lo mejor de tu empresa en Cuentanos.mx</p>
                <div class="cta-buttons">
                    <a href="<?php echo home_url('/registrar-negocio'); ?>" class="btn btn-primary btn-lg">Registrar mi negocio</a>
                    <a href="<?php echo home_url('/directorio'); ?>" class="btn btn-lg" style="background: rgba(255,255,255,0.15); color: white; border: 2px solid rgba(255,255,255,0.3);">Explorar directorio</a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_template_part('template-parts/footer'); ?>
