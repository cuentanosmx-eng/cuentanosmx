<?php
/**
 * Header Template - Airbnb Style
 */

$current_user = wp_get_current_user();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  
  <!-- Navbar -->
  <nav class="navbar" id="navbar">
    <div class="container">
      <div class="navbar-inner">
        
        <!-- Logo -->
        <a href="<?php echo home_url(); ?>" class="navbar-logo">
          <svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
          Cuentanos.mx
        </a>
        
        <!-- Nav Links -->
        <div class="navbar-nav">
          <a href="<?php echo home_url(); ?>" class="navbar-link">Inicio</a>
          <a href="<?php echo home_url('/directorio'); ?>" class="navbar-link">Explorar</a>
          <?php if (is_user_logged_in()): ?>
            <a href="<?php echo home_url('/perfil'); ?>" class="navbar-link">Mi Perfil</a>
          <?php endif; ?>
        </div>
        
        <!-- Actions -->
        <div class="navbar-actions">
          
          <?php if (is_user_logged_in()): ?>
            <a href="<?php echo home_url('/perfil'); ?>" class="megafonos-badge">
              <span>🎤</span>
              <span>50</span>
            </a>
            
            <div class="dropdown">
              <button class="dropdown-btn" id="dropdownBtn">
                <span><?php echo substr($current_user->display_name, 0, 1); ?></span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>
              <div class="dropdown-menu" id="dropdownMenu">
                <div class="dropdown-item" style="background: var(--gray-50); pointer-events: none;">
                  <strong><?php echo esc_html($current_user->display_name); ?></strong>
                </div>
                <a href="<?php echo home_url('/perfil'); ?>" class="dropdown-item">Mi Perfil</a>
                <a href="<?php echo home_url('/registrar-negocio'); ?>" class="dropdown-item">Agregar Negocio</a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo wp_logout_url(home_url()); ?>" class="dropdown-item" style="color: var(--error);">Cerrar sesión</a>
              </div>
            </div>
          <?php else: ?>
            <a href="<?php echo home_url('/mi-cuenta'); ?>" class="btn btn-outline">Iniciar sesión</a>
            <a href="<?php echo home_url('/registro'); ?>" class="btn btn-primary">Registrarse</a>
          <?php endif; ?>
          
        </div>
      </div>
    </div>
  </nav>

  <div id="main-content">
