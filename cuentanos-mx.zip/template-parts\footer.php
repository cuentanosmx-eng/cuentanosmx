<?php
/**
 * Footer Template - Airbnb Style
 */
?>
  </div><!-- #main-content -->

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-brand">
          <a href="<?php echo home_url(); ?>" class="footer-logo">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
            </svg>
            Cuentanos.mx
          </a>
          <p>Descubre los mejores negocios locales en México.</p>
        </div>
        
        <div class="footer-links">
          <div class="footer-col">
            <h4>Explorar</h4>
            <a href="<?php echo home_url('/directorio'); ?>">Directorio</a>
            <a href="<?php echo home_url('/directorio?categoria=restaurantes'); ?>">Restaurantes</a>
            <a href="<?php echo home_url('/directorio?categoria=hoteles'); ?>">Hoteles</a>
            <a href="<?php echo home_url('/directorio?categoria=cafeterias'); ?>">Cafeterías</a>
          </div>
          
          <div class="footer-col">
            <h4>Negocios</h4>
            <a href="<?php echo home_url('/registrar-negocio'); ?>">Registrar negocio</a>
            <a href="<?php echo home_url('/mi-negocio'); ?>">Mi negocio</a>
          </div>
          
          <div class="footer-col">
            <h4>Cuenta</h4>
            <a href="<?php echo home_url('/registro'); ?>">Registrarse</a>
            <a href="<?php echo home_url('/mi-cuenta'); ?>">Iniciar sesión</a>
            <a href="<?php echo home_url('/perfil'); ?>">Mi perfil</a>
          </div>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> Cuentanos.mx. Todos los derechos reservados.</p>
      </div>
    </div>
  </footer>

  <?php wp_footer(); ?>
  
  <script>
  document.addEventListener('DOMContentLoaded', function() {
    var dropdownBtn = document.getElementById('dropdownBtn');
    var dropdownMenu = document.getElementById('dropdownMenu');
    
    if (dropdownBtn && dropdownMenu) {
      dropdownBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        dropdownMenu.classList.toggle('active');
      });
      
      document.addEventListener('click', function() {
        dropdownMenu.classList.remove('active');
      });
      
      dropdownMenu.addEventListener('click', function(e) {
        e.stopPropagation();
      });
    }
  });
  </script>

</body>
</html>
